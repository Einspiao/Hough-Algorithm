# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.

import sys
import tkinter as tk
from tkinter import filedialog
import os
import re
import numpy as np
# import matplotlib.pyplot as plt
import h5py


def click():
    # file_name = filedialog.askdirectory(title='Choose dataset directory', initialdir='/Users/wsp/Downloads')
    file_name = filedialog.askdirectory(title='Choose dataset directory', initialdir=os.getcwd())
    path_var.set(file_name)


def txt_readout(data_path):
    data_this_file = []
    f = open(data_path, 'rb')
    start_sign = [b'>', b'>']
    pointer_position = ['1', '2']
    while pointer_position != start_sign:
        pointer_position[0] = f.read(1)
        pointer_position[1] = f.read(1)
        f.seek(-1, 1)
    f.seek(3, 1)
    one_data = f.readline().split(b',')
    while one_data != [b'']:
        data_this_file.append(float(one_data[0])+1j*float(one_data[1]))
        one_data = f.readline().split(b',')
    return data_this_file


def readout_data(data_dir, f_num):
    global Freqs, Dataset, Temperature
    data_list = os.listdir(data_dir)
    data_list.sort()
    if len(data_list) % int(f_num) == 1:
        del data_list[0]  # mind this point ! ! ! ! !
    elif len(data_list) % int(f_num) != 0:
        # print(len(data_list), f_num)
        sys.exit('File number doesn\'t match')
    iteration = int(len(data_list)/f_num)
    Temperature = [0 for row in range(iteration)]
    Dataset = [[0+0*1j] for row in range(iteration)]
    # Read frequency number
    first_file = data_list[0]
    last_file = data_list[f_num-1]
    f_start = float(re.findall(r'\d+', first_file[first_file.index('fcent='):])[0])
    f_end = float(re.findall(r'\d+', last_file[last_file.index('fcent='):])[0])
    f_span = float(re.findall(r'\d+', first_file[first_file.index('fspan='):])[0])
    points_num = int(re.findall(r'\d+', first_file[first_file.index('npoints='):])[0])
    Freqs = np.linspace(f_start-1/2*f_span, f_end+1/2*f_span, f_num*points_num)
    # Read Dataset and Temperature
    for i in range(iteration):
        t_sum = 0
        for j in range(f_num):
            # Read amplitude
            data_path = os.path.join(data_dir, data_list[i*f_num+j])
            Dataset[i] = Dataset[i]+txt_readout(data_path)
            # Read temperature
            # To Do : Read general form of number or confirm the format of temperature
            i_t = data_path.index('temp=')+5
            t_sum = t_sum+float(data_path[i_t:i_t+10])  # not general for temperature readout
        Temperature[i] = t_sum/f_num
    for i in range(len(Dataset)):
        del Dataset[i][0]  # See whether there is a better method


def click_get():
    readout_data(entry_data.get(), int(entry_fnum.get()))
    window.destroy()
    # print(data_list)


def hough3(x, y, revstep, rstep, peak_range):
    # x, y must be ndarray for using np.max() and np.min()
    thetastep = 100

    x_min = np.min(x)
    x_max = np.max(x)
    y_min = np.min(y)
    y_max = np.max(y)
    d = np.max([x_max - x_min, y_max - y_min])

    l = 1.5
    x_rev = (x_max - x_min + 2 * l * d) / revstep
    y_rev = (y_max - y_min + 2 * l * d) / revstep

    N = len(x)
    k1 = 0.5
    k2 = 1.5
    r = np.linspace(k1*d, k2*d, rstep)
    T = np.zeros((revstep, revstep, rstep))

    for i in range(rstep):
        for k in range(N):
            for j in range(thetastep):
                theta = 2*np.pi/thetastep*j
                a = x[k]-r[i]*np.cos(theta)
                b = y[k]-r[i]*np.sin(theta)
                m = round((a-x_min+l*d)/x_rev)
                n = round((b-y_min+l*d)/y_rev)
                if m < 0 or n < 0 or m > revstep-1 or n > revstep-1:
                    continue
                T[m, n, i] = T[m, n, i]+1
    p = [[0 for d1 in range(rstep)] for d2 in range(3)]
    # peak_range from input variables
    for j in range(rstep):
        pi_sequence = T[:, :, j].argmax(axis=0)
        p_sequence = T[:, :, j].max(axis=0)
        pi_1 = p_sequence.argmax()
        pi_0 = pi_sequence[pi_1]
        # pi_0, pi_1 are the first and second index of peak in T[:,:,j]
        sum_total = np.sum(T[:, :, j])
        if pi_0-peak_range < 0 or pi_1-peak_range < 0 or pi_0+peak_range > revstep-1 or pi_1+peak_range > revstep-1:
            continue
        sum_peak = np.sum(T[pi_0-peak_range:pi_0+peak_range+1, pi_1-peak_range:pi_1+peak_range+1, j])
        p[0][j] = sum_peak/sum_total
        p[1][j] = x_min-l*d+x_rev*pi_0
        p[2][j] = y_min-l*d+y_rev*pi_1
    peak_portion = max(p[0])
    index = p[0].index(peak_portion)
    x_center = p[1][index]
    y_center = p[2][index]
    r_fine = k1*d+(k2-k1)*d*index/revstep
    return x_center, y_center, r_fine, peak_portion


def revise_delay(s_sequence):
    s_sequence = np.array(s_sequence)
    # Input - complex amplitude, from Dataset it's a list
    # Output - revised complex amplitude according to cable delay theory
    f = list(Freqs)
    split_angle = np.angle(s_sequence)
    min_jump = 0.7*2*np.pi
    # cut abnormal points
    i = 1
    while i <= len(split_angle)-1:
        if split_angle[i-1]-split_angle[i] > min_jump:
            split_angle = np.delete(split_angle, i)
            del f[i]
            continue
        i = i+1
    new_angle = np.array([0.0 for d in range(len(split_angle))])
    new_angle[0] = split_angle[0]
    phase_shift = 0
    for i in range(1, len(f)):
        if split_angle[i]-split_angle[i-1] > min_jump:
            phase_shift = phase_shift+1
            new_angle[i] = split_angle[i]-2*np.pi*phase_shift
        else:
            new_angle[i] = split_angle[i]-2*np.pi*phase_shift
    tau = np.polyfit(f, new_angle, 1)[0]
    for i in range(len(s_sequence)):
        s_sequence[i] = s_sequence[i]*np.exp(-1j*Freqs[i]*tau)
    return s_sequence


def hough_fit():
    revstep = int(entry_revstep.get())
    rstep = int(entry_r_step.get())
    peak_range = int(entry_peak_range.get())
    threshold = float(entry_threshold.get())
    search_step = float(entry_search_step.get())
    search_len = float(entry_search_len.get())
    # fit_result = [[] for row in range(len(Dataset))]
    # create hdf5 file to load data
    f = h5py.File('selected.h5', 'w')
    f.close()

    for i in range(len(Dataset)):
        peak_find = []
        p_full_range = []
        x_center = []
        y_center = []
        r_sequence = []
        amp_cplx = Dataset[i]
        for j in range(int((len(amp_cplx)-search_len)/search_step)):
            amp_part = amp_cplx[int(j*search_step):int(j*search_step+search_len)]
            x_c, y_c, r_fine, peak_portion = hough3(np.real(amp_part), np.imag(amp_part), revstep, rstep, peak_range)
            # def hough3(x, y, revstep, rstep, peak_range)
            x_center.append(x_c)
            y_center.append(y_c)
            r_sequence.append(r_fine)
            p_full_range.append(peak_portion)
        p_max = max(p_full_range)
        for k in range(1, len(p_full_range)-1):
            if p_full_range[k] > threshold*p_max:
                peak_find.append([int(k*search_step), int(k*search_step+search_len), x_center[k], y_center[k], r_sequence[k]])
                # structure of found peak
        for m in range(len(peak_find)):
            left_add = 0
            while peak_find[m][0]-1 >= 0:
                if left_add < 200 and np.abs(np.abs(amp_cplx[peak_find[m][0]-1]-peak_find[m][2]-peak_find[m][3]*1j)-peak_find[m][4]) < 0.15*peak_find[m][4]:
                    peak_find[m][0] = peak_find[m][0]-1
                    left_add = left_add + 1
                else:
                    break
            right_add = 0
            while peak_find[m][1]+1 < len(amp_cplx):
                if right_add < 200 and np.abs(np.abs(amp_cplx[peak_find[m][1]+1]-peak_find[m][2]-peak_find[m][3]*1j)-peak_find[m][4]) < 0.15*peak_find[m][4]:
                    peak_find[m][1] = peak_find[m][1]+1
                    right_add = right_add + 1
                else:
                    break
            # print('tic')
            # p = circle.circuit.notch_port(f_data=Freqs[peak_find[m][0]:peak_find[m][1]], z_data_raw=amp_cplx[peak_find[m][0]:peak_find[m][1]])
            # p.autofit()
            # print('toc')
            # fit_result[i] = fit_result[i]+[p.fitresults['fr'], p.fitresults['Ql']]
        # write data in h5
        f = h5py.File('selected.h5', 'a')
        group = f.create_group('T='+str(Temperature[i]))
        for t in range(len(peak_find)):
            group.create_dataset('freqs'+str(t), data=Freqs[peak_find[t][0]:peak_find[t][1]])
            group.create_dataset('amplitude'+str(t), data=amp_cplx[peak_find[t][0]:peak_find[t][1]])
        f.close()
        print('one step of temperature')


Freqs = []  # ndarray
Dataset = []  # list
Temperature = []  # list

window = tk.Tk()
window.title('Choose data file directory')
window.geometry('400x200')

label_filepath = tk.Label(window, text='Please choose the file you store data:')
label_filepath.place(x=10, y=10, anchor='nw')

label_filenumber = tk.Label(window, text='Please entry the files\' number for one temperature scan:')
label_filenumber.place(x=10, y=90, anchor='nw')

path_var = tk.StringVar()
# Entry box for chosen directory
entry_data = tk.Entry(window, textvariable=path_var)
entry_data.place(x=10, y=50, anchor='nw')
# Button for choosing file
button_choose = tk.Button(window, text='Choose File', command=click)
button_choose.place(x=220, y=50, anchor='nw')
# Entry box for frequency iteration

default_f = tk.StringVar(value=9)
entry_fnum = tk.Entry(window, textvariable=default_f)
entry_fnum.place(x=10, y=130, anchor='nw')

# Button for reading file
button_get = tk.Button(window, text='Get', command=click_get)
button_get.place(x=220, y=130, anchor='nw')

window.mainloop()

print(np.array(Dataset).shape)

for i in range(len(Dataset)):
    Dataset[i] = revise_delay(Dataset[i])

# Start of fitting

window = tk.Tk()
window.title('Fit Settings')
window.geometry('800x550')

label_revstep = tk.Label(window, text='Hough Algorithm (HA) Resolution (Integer):')
label_revstep.place(x=10, y=10, anchor='nw')
default1 = tk.StringVar(value=150)
entry_revstep = tk.Entry(window, textvariable=default1)
entry_revstep.place(x=10, y=50, anchor='nw')

label_r_step = tk.Label(window, text='Radius Precision of HA (Integer):')
label_r_step.place(x=10, y=90, anchor='nw')
default2 = tk.StringVar(value=100)
entry_r_step = tk.Entry(window, textvariable=default2)
entry_r_step.place(x=10, y=130, anchor='nw')

label_peak_range = tk.Label(window, text='HA Resistance to Noise (Large Value for Noisy Data, Integer):')
label_peak_range.place(x=10, y=170, anchor='nw')
default3 = tk.StringVar(value=1)
entry_peak_range = tk.Entry(window, textvariable=default3)
entry_peak_range.place(x=10, y=210, anchor='nw')

label_threshold = tk.Label(window, text='HA Threshold for Peaks (the Smaller the More Sensitive, MUST IN (0,1):')
label_threshold.place(x=10, y=250, anchor='nw')
default4 = tk.StringVar(value=0.4)
entry_threshold = tk.Entry(window, textvariable=default4)
entry_threshold.place(x=10, y=290, anchor='nw')

label_search_step = tk.Label(window, text='Data Points Between Two steps (typically equals to L/3, Integer)*:')
label_search_step.place(x=10, y=330, anchor='nw')
default5 = tk.StringVar(value=0)  # 15
entry_search_step = tk.Entry(window, textvariable=default5)
entry_search_step.place(x=10, y=370, anchor='nw')

label_search_len = tk.Label(window, text='Data Points Analyzed in one step (typically equals to L, Integer)*:')
label_search_len.place(x=10, y=410, anchor='nw')
default6 = tk.StringVar(value=0)  # 40
entry_search_len = tk.Entry(window, textvariable=default6)
entry_search_len.place(x=10, y=450, anchor='nw')

label_L = tk.Label(window, text='*L = Data Points Number of a Typical Peak in YOUR Data. It varies under different condition.', bg='yellow')
label_L.place(x=10, y=490, anchor='nw')

button_fit = tk.Button(window, text='Fit', command=hough_fit, height=3, width=6)
button_fit.place(x=650, y=250, anchor='nw')

window.mainloop()
