import h5py
import matplotlib.pyplot as plt
import sys
import qkit
import qkit.analysis.circle_fit as circle
sys.path.append('qkit-master')
qkit.cfg["circle_fit_version"] = 2


f = h5py.File('selected.h5', 'r')
Data_T = []
for group in f.keys():
    g = f[group]
    dataset = list(g.keys())
    for i in range(int(len(dataset)/2)):
        amp = f[group][dataset[i]][:]
        freqs = f[group][dataset[i+int(len(dataset)/2)]][:]
        p = circle.circuit.notch_port(f_data=freqs, z_data_raw=amp)
        p.autofit()
        if p.fitresults['Ql_err'] > 0.1*p.fitresults['Ql']:
            continue
        else:
            # print(p.fitresults)
            # p.plotall()
            Data_T.append([float(group[2:]), p.fitresults['fr'], p.fitresults['Ql']])

plt.figure(1)
for i in range(len(Data_T)):
    plt.scatter(Data_T[i][0], Data_T[i][1], s=1, c=Data_T[i][2])
plt.colorbar()
plt.show()