The calibration files .cal have a python2 codec.
With the notebooks they can be convertet to python3 .npy files